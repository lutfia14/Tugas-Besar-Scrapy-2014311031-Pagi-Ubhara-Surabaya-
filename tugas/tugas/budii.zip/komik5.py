import scrapy


class QuotesSpider(scrapy.Spider):
    name = "quotes"

    def start_requests(self):
        urls = [
            'https://www.worldnovel.online/invincible-conqueror/invincible-chapter-01-wind-snow-continent-bahasa-indonesia/',
            'https://www.worldnovel.online/invincible-conqueror/invincible-chapter-02-grade-seven-martial-spirit-bahasa-indonesia/',
            'https://www.worldnovel.online/invincible-conqueror/invincible-chapter-03-only-xiaolong-did-not-get-any-bahasa-indonesia/',
            'https://www.worldnovel.online/invincible-conqueror/invincible-chapter-04-the-annual-clan-assembly-bahasa-indonesia/',
            'https://www.worldnovel.online/invincible-conqueror/invincible-chapter-05-wants-to-cripple-both-of-my-arms-bahasa-indonesia/',
            'https://www.worldnovel.online/invincible-conqueror/invincible-chapter-06-it-is-useless-to-beg-me-bahasa-indonesia/',
            'https://www.worldnovel.online/invincible-conqueror/invincible-chapter-07-an-odd-valley-bahasa-indonesia/',
            'https://www.worldnovel.online/invincible-conqueror/invincible-chapter-08-fortuitous-adventure-at-the-bottom-of-the-lake-bahasa-indonesia/',
            'https://www.worldnovel.online/invincible-conqueror/invincible-chapter-09-blades-of-asura-bahasa-indonesia/',
            'https://www.worldnovel.online/invincible-conqueror/invincible-chapter-10-thousand-year-old-leirion-heart-grass-bahasa-indonesia/',
            
        ]
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)
    
    

    def parse(self, response):
        yield{
            'testing':response.css('#soop > p ::text').extract()
        }